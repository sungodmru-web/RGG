# Reclaiming the Green Gold — Source Export

This archive contains the existing website source without redesigns, refactors, or dependency upgrades.

## Included

- `artifacts/rgg-website/` — React + Vite website, pages, components, styles, SEO metadata, and public images
- `artifacts/api-server/` — Express API server and routes
- `lib/` — API specification, generated API clients/schemas, and database schema/configuration
- `scripts/` — workspace utility scripts
- Root pnpm workspace, TypeScript, Replit, and build configuration
- `.env.example` — safe local placeholders only

## Local setup

1. Install Node.js and pnpm.
2. Run `pnpm install` from the archive root.
3. Copy `.env.example` to `.env` only if local environment values are needed.
4. Run the website with `pnpm --filter @workspace/rgg-website run dev`.
5. Run the API server separately with `pnpm --filter @workspace/api-server run dev` if required.

The current website is presentation-first and does not require the database or API server for its main page. Purchase buttons and several forms are present in the UI, but the current source does not contain a completed BookVault checkout integration or functional form backend.
